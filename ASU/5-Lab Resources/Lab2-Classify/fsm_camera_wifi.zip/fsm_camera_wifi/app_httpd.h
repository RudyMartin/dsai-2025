#pragma once

#include "esp_http_server.h"

esp_err_t startCameraServer();
