
# Lab 6 – Config‑Driven Robot Arm

*(60‑minute lesson)*

## Objectives
* Map the 1‑2‑3‑4‑5 MCP loop to a JSON‑driven robot.
* Edit `robot_cfg.json` to fit any servo layout.
* Deploy a single firmware image to multiple arm types.

## Timeline
| Min | Activity |
|----|-----------|
| 0‑5 | Teacher demo – tiny & big arm both wave. |
| 5‑15 | Explain `servos` and `actions` sections of JSON. |
| 15‑25 | Teams wire servos to PCA9685. |
| 25‑35 | Walk through FSM code – highlight SENSE→PLAN→ACT. |
| 35‑50 | Students tweak POINT action and re‑upload data only. |
| 50‑60 | Share results, discuss advantages of config files. |

## Quick Start
1. Select **ESP32 Dev Module** → 240 MHz.
2. Upload *data* (`robot_cfg.json`) via “ESP32 Sketch Data Upload”.
3. Flash `6_4_RobotCfgFSM.ino`.
4. Open Serial @115200; type `WAVE`, `POINT`, etc.

## Safety
* Limit supply to 5 V 2 A.
* Keep fingers clear of gripper.
* Use `RESET` command for emergency stop.
